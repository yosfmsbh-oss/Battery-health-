package com.example.batteryhealth

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import java.util.Locale
import rikka.shizuku.Shizuku
import android.widget.TextView

class MainActivity : Activity() {

    private val ink = Color.parseColor("#12332B")
    private val sub = Color.parseColor("#4D6B62")
    private val bg = Color.parseColor("#E8F3EE")
    private val card = Color.parseColor("#F6FBF8")
    private val line = Color.parseColor("#C5DDD3")
    private val ok = Color.parseColor("#2F9E6E")
    private val warn = Color.parseColor("#D99A1C")
    private val bad = Color.parseColor("#D6453D")

    private lateinit var big: TextView
    private lateinit var verdict: TextView
    private lateinit var source: TextView
    private lateinit var rows: LinearLayout
    private lateinit var designInput: EditText
    private lateinit var shzStatus: TextView
    private lateinit var devicesBox: LinearLayout
    private lateinit var btStatus: TextView
    private lateinit var btButton: Button
    private var lastSig = ""
    private var last: Intent? = null

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            try {
                registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let {
                    last = it
                    render(it)
                }
            } catch (t: Throwable) { }
            handler.postDelayed(this, 3000)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            last = i
            try { render(i) } catch (t: Throwable) { showError(t) }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            buildUi()
        } catch (t: Throwable) {
            showError(t)
        }
    }

    private fun showError(t: Throwable) {
        val tv = TextView(this)
        tv.text = "حصل خطأ، صوّر هذي الشاشة وارسلها:\n\n" + android.util.Log.getStackTraceString(t)
        tv.setTextIsSelectable(true)
        tv.textSize = 12f
        tv.setPadding(dp(16), dp(40), dp(16), dp(16))
        val sv = ScrollView(this)
        sv.addView(tv)
        setContentView(sv)
    }

    private fun buildUi() {

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(40), dp(20), dp(32))

        val title = TextView(this)
        title.text = "صحة البطارية"
        title.textSize = 22f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(ink)
        col.addView(title)

        big = TextView(this)
        big.textSize = 76f
        big.setTypeface(null, Typeface.BOLD)
        big.gravity = Gravity.CENTER
        big.setTextColor(ink)
        big.layoutDirection = View.LAYOUT_DIRECTION_LTR
        col.addView(big, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })

        verdict = TextView(this)
        verdict.textSize = 18f
        verdict.setTypeface(null, Typeface.BOLD)
        verdict.gravity = Gravity.CENTER
        verdict.setTextColor(ink)
        col.addView(verdict, LinearLayout.LayoutParams(-1, -2))

        source = TextView(this)
        source.textSize = 13f
        source.gravity = Gravity.CENTER
        source.setTextColor(sub)
        col.addView(source, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        val devTitle = TextView(this)
        devTitle.text = "البطارية والأجهزة المتصلة"
        devTitle.textSize = 16f
        devTitle.setTypeface(null, Typeface.BOLD)
        devTitle.setTextColor(ink)
        col.addView(devTitle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })

        devicesBox = LinearLayout(this)
        devicesBox.orientation = LinearLayout.VERTICAL
        col.addView(devicesBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        btStatus = TextView(this)
        btStatus.textSize = 12f
        btStatus.setTextColor(sub)
        col.addView(btStatus, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        btButton = Button(this)
        btButton.text = "السماح بالوصول للبلوتوث"
        btButton.visibility = View.GONE
        btButton.setOnClickListener {
            requestPermissions(arrayOf("android.permission.BLUETOOTH_CONNECT"), 2001)
        }
        col.addView(btButton, LinearLayout.LayoutParams(-1, -2))

        rows = LinearLayout(this)
        rows.orientation = LinearLayout.VERTICAL
        rows.background = GradientDrawable().apply {
            setColor(card)
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), line)
        }
        col.addView(rows, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(28) })

        val hint = TextView(this)
        hint.text = "إذا ما قدر التطبيق يعرف السعة الأصلية، اكتبها هنا (مثل 5000) واضغط حفظ."
        hint.textSize = 14f
        hint.setTextColor(sub)
        col.addView(hint, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })

        designInput = EditText(this)
        designInput.inputType = InputType.TYPE_CLASS_NUMBER
        designInput.hint = "السعة الأصلية بالـ mAh"
        designInput.setTextColor(ink)
        val saved = savedDesign()
        if (saved != null) designInput.setText(saved.toInt().toString())
        col.addView(designInput, LinearLayout.LayoutParams(-1, -2))

        val save = Button(this)
        save.text = "حفظ"
        save.setOnClickListener {
            val v = designInput.text.toString().toFloatOrNull() ?: 0f
            getSharedPreferences("p", MODE_PRIVATE).edit().putFloat("design", v).apply()
            last?.let { render(it) }
        }
        col.addView(save, LinearLayout.LayoutParams(-1, -2))

        val shz = Button(this)
        shz.text = "منح الصلاحية عبر Shizuku"
        shz.setOnClickListener { grantViaShizuku() }
        col.addView(shz, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        shzStatus = TextView(this)
        shzStatus.textSize = 13f
        shzStatus.setTextColor(sub)
        col.addView(shzStatus, LinearLayout.LayoutParams(-1, -2))

        scroll.addView(col)
        setContentView(scroll)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    override fun onStart() {
        super.onStart()
        handler.postDelayed(ticker, 3000)
        try {
            val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val sticky = if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(receiver, f)
            }
            sticky?.let { last = it; render(it) }
        } catch (t: Throwable) {
            showError(t)
        }
    }

    private val shzListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) {
            runGrant()
        } else {
            runOnUiThread { shzStatus.text = "تم رفض صلاحية Shizuku" }
        }
    }

    private fun grantViaShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                shzStatus.text = "Shizuku غير شغال. افتح تطبيق Shizuku وشغّله أولاً"
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                runGrant()
            } else {
                Shizuku.addRequestPermissionResultListener(shzListener)
                Shizuku.requestPermission(1001)
            }
        } catch (t: Throwable) {
            shzStatus.text = "خطأ: " + t.message
        }
    }

    private fun runGrant() {
        runOnUiThread { shzStatus.text = "جاري منح الصلاحية…" }
        Thread {
            val msg = try {
                val m = Shizuku::class.java.getDeclaredMethod(
                    "newProcess",
                    Array<String>::class.java,
                    Array<String>::class.java,
                    String::class.java
                )
                m.isAccessible = true
                val cmd = arrayOf("pm", "grant", packageName, "android.permission.BATTERY_STATS")
                val p = m.invoke(null, cmd, null, null) as Process
                val err = p.errorStream.bufferedReader().readText()
                val code = p.waitFor()
                if (code == 0) "تم منح الصلاحية" else "فشل: $err"
            } catch (t: Throwable) {
                "خطأ: " + (t.cause?.message ?: t.message)
            }
            runOnUiThread {
                shzStatus.text = msg
                last?.let { try { render(it) } catch (t: Throwable) { showError(t) } }
            }
        }.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { Shizuku.removeRequestPermissionResultListener(shzListener) } catch (t: Throwable) { }
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(ticker)
        try { unregisterReceiver(receiver) } catch (e: Exception) { }
    }

    private fun savedDesign(): Double? {
        val v = getSharedPreferences("p", MODE_PRIVATE).getFloat("design", 0f)
        return if (v > 0f) v.toDouble() else null
    }

    private fun autoDesign(): Double? = try {
        val c = Class.forName("com.android.internal.os.PowerProfile")
        val o = c.getConstructor(Context::class.java).newInstance(this)
        (c.getMethod("getBatteryCapacity").invoke(o) as Double).takeIf { it > 0 }
    } catch (e: Throwable) {
        null
    }

    private inner class RingView(c: Context, private val pct: Int, private val ringColor: Int) : View(c) {
        private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(7).toFloat()
            color = line
        }
        private val prog = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(7).toFloat()
            strokeCap = Paint.Cap.ROUND
            color = ringColor
        }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            textSize = dp(16).toFloat()
            typeface = Typeface.DEFAULT_BOLD
            color = ink
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val pad = dp(7).toFloat()
            val rect = RectF(pad, pad, w - pad, h - pad)
            canvas.drawArc(rect, 0f, 360f, false, track)
            if (pct >= 0) canvas.drawArc(rect, -90f, 360f * pct / 100f, false, prog)
            val label = if (pct >= 0) "$pct%" else "—"
            canvas.drawText(label, w / 2, h / 2 + txt.textSize / 3, txt)
        }
    }

    private class Dev(val name: String, val kind: String, val pct: Int)

    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            checkSelfPermission("android.permission.BLUETOOTH_CONNECT") == PackageManager.PERMISSION_GRANTED

    private fun connectedDevices(): List<Dev> {
        val out = ArrayList<Dev>()
        if (!hasBtPermission()) return out
        val adapter: android.bluetooth.BluetoothAdapter = try {
            (getSystemService(BLUETOOTH_SERVICE) as android.bluetooth.BluetoothManager).adapter
        } catch (t: Throwable) {
            null
        } ?: return out
        val bonded = try { adapter.bondedDevices } catch (t: Throwable) { return out }
        for (d in bonded) {
            val connected = try {
                d.javaClass.getMethod("isConnected").invoke(d) as Boolean
            } catch (t: Throwable) {
                false
            }
            if (!connected) continue
            val lvl = try {
                d.javaClass.getMethod("getBatteryLevel").invoke(d) as Int
            } catch (t: Throwable) {
                -1
            }
            val name = (try { d.name } catch (t: Throwable) { null }) ?: d.address
            val n = name.lowercase()
            val cls = try { d.bluetoothClass?.majorDeviceClass } catch (t: Throwable) { null }
            val kind = when {
                n.contains("watch") || cls == android.bluetooth.BluetoothClass.Device.Major.WEARABLE -> "ساعة"
                n.contains("buds") || n.contains("pods") || n.contains("ear") -> "سماعة أذن"
                cls == android.bluetooth.BluetoothClass.Device.Major.AUDIO_VIDEO -> "سماعة"
                else -> "جهاز"
            }
            out.add(Dev(name, kind, if (lvl in 0..100) lvl else -1))
        }
        return out
    }

    private fun makeCard(name: String, sub2: String, pct: Int): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.setPadding(dp(6), dp(14), dp(6), dp(12))
        c.background = GradientDrawable().apply {
            setColor(card)
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), line)
        }
        val ringColor = if (pct < 0) line else if (pct <= 15) bad else if (pct <= 40) warn else ok
        c.addView(RingView(this, pct, ringColor), LinearLayout.LayoutParams(dp(72), dp(72)))
        val nm = TextView(this)
        nm.text = name
        nm.textSize = 13f
        nm.setTypeface(null, Typeface.BOLD)
        nm.setTextColor(ink)
        nm.gravity = Gravity.CENTER
        nm.setSingleLine(true)
        nm.ellipsize = TextUtils.TruncateAt.END
        c.addView(nm, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val sb = TextView(this)
        sb.text = sub2
        sb.textSize = 11f
        sb.setTextColor(sub)
        sb.gravity = Gravity.CENTER
        c.addView(sb, LinearLayout.LayoutParams(-1, -2))
        return c
    }

    private fun updateDevices(phonePct: Int, charging: Boolean) {
        val perm = hasBtPermission()
        val devs = connectedDevices()
        val sig = "$phonePct|$charging|$perm|" + devs.joinToString(";") { "${it.name}:${it.pct}" }
        if (sig == lastSig) return
        lastSig = sig

        val items = ArrayList<LinearLayout>()
        items.add(makeCard("هذا الجوال", if (charging) "يشحن" else "الجوال", phonePct))
        for (d in devs) items.add(makeCard(d.name, d.kind, d.pct))

        devicesBox.removeAllViews()
        var idx = 0
        while (idx < items.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 3) {
                val lp = LinearLayout.LayoutParams(0, -2, 1f).apply {
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                }
                if (idx + k < items.size) row.addView(items[idx + k], lp)
                else row.addView(View(this), lp)
            }
            devicesBox.addView(row, LinearLayout.LayoutParams(-1, -2))
            idx += 3
        }

        btButton.visibility = if (perm) View.GONE else View.VISIBLE
        btStatus.text = when {
            !perm -> "اسمح للتطبيق بالوصول للبلوتوث عشان يعرض بطارية السماعة والساعة."
            devs.isEmpty() -> "ما فيه أجهزة بلوتوث متصلة الآن."
            devs.any { it.pct < 0 } -> "الرمز — يعني الجهاز ما يرسل نسبة بطاريته لأندرويد. سماعات وساعات سامسونج غالباً تعرضها Galaxy Wearable فقط."
            else -> ""
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        lastSig = ""
        last?.let { try { render(it) } catch (t: Throwable) { showError(t) } }
    }

    private fun addRow(label: String, value: String) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.setPadding(dp(18), dp(14), dp(18), dp(14))
        val a = TextView(this)
        a.text = label
        a.textSize = 16f
        a.setTextColor(sub)
        val b = TextView(this)
        b.text = value
        b.textSize = 16f
        b.setTypeface(null, Typeface.BOLD)
        b.setTextColor(ink)
        b.gravity = Gravity.END
        r.addView(a, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        rows.addView(r)
    }

    private fun render(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) / 10.0
        val volt = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
        val hc = i.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)
        val cycles = i.getIntExtra("android.os.extra.CYCLE_COUNT", -1)

        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val soh = try {
            if (Build.VERSION.SDK_INT >= 34) bm.getIntProperty(10) else -1
        } catch (t: Throwable) {
            -1
        }
        val counter = try {
            bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        } catch (t: Throwable) {
            -1L
        }
        val design = savedDesign() ?: autoDesign()
        val estFull = if (pct >= 20 && counter > 0) counter / 1000.0 / (pct / 100.0) else null

        var health: Int? = null
        var src = ""
        if (soh in 1..100) {
            health = soh
            src = "القيمة من نظام الجهاز"
        } else if (estFull != null && design != null && design > 0) {
            health = Math.min(100, Math.round(estFull / design * 100).toInt())
            src = "تقدير من السعة الحالية والأصلية"
        }

        if (health != null) {
            big.text = "$health%"
            val color = if (health >= 80) ok else if (health >= 70) warn else bad
            big.setTextColor(color)
            verdict.setTextColor(color)
            verdict.text = when {
                health >= 90 -> "ممتازة"
                health >= 80 -> "جيدة"
                health >= 70 -> "متوسطة، قرّب تغييرها"
                else -> "ضعيفة، يفضّل تغيير البطارية"
            }
            source.text = src
        } else {
            big.text = "؟"
            big.setTextColor(ink)
            verdict.setTextColor(ink)
            source.text = ""
            verdict.text = when {
                design == null -> "اكتب السعة الأصلية بالأسفل"
                pct in 0..19 -> "الشحن أقل من 20%، التقدير يحتاج 20% أو أكثر"
                else -> "الجهاز ما يعطي بيانات كافية"
            }
        }

        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val curRaw = try {
            bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        } catch (t: Throwable) {
            Int.MIN_VALUE
        }
        var mA: Double? = null
        if (curRaw != Int.MIN_VALUE && curRaw != 0) {
            val a = Math.abs(curRaw).toDouble()
            mA = if (a >= 20000) a / 1000.0 else a
        }
        val watts = if (mA != null && volt > 0) mA * volt / 1_000_000.0 else null
        val chargerType = when {
            (plugged and BatteryManager.BATTERY_PLUGGED_WIRELESS) != 0 -> "لاسلكي"
            (plugged and BatteryManager.BATTERY_PLUGGED_AC) != 0 -> "شاحن جداري (AC)"
            (plugged and BatteryManager.BATTERY_PLUGGED_USB) != 0 -> "USB"
            else -> null
        }

        try { updateDevices(pct, charging) } catch (t: Throwable) { }
        rows.removeAllViews()
        addRow("النسبة الحالية", if (pct >= 0) "$pct%" else "غير متاح")
        addRow("الحالة", if (charging) "يشحن" else "يستخدم البطارية")
        if (charging && chargerType != null) addRow("نوع الشاحن", chargerType)
        if (watts != null) {
            val w = String.format(Locale.US, "%.1f", watts)
            if (charging) {
                addRow("قوة الشحن الحالية", "$w واط")
                addRow(
                    "سرعة الشحن",
                    if (watts >= 25) "فائقة" else if (watts >= 15) "سريعة" else "عادية"
                )
            } else {
                addRow("الاستهلاك الحالي", "$w واط")
            }
            addRow("التيار", "${mA?.toInt() ?: 0} mA")
        }
        if (estFull != null) addRow("السعة الحالية (تقدير)", "${estFull.toInt()} mAh")
        if (design != null) addRow("السعة الأصلية", "${design.toInt()} mAh")
        if (cycles >= 0) addRow("دورات الشحن", cycles.toString())
        if (temp > 0) addRow("الحرارة", "$temp °C")
        if (volt > 0) addRow("الجهد", "$volt mV")
        addRow(
            "حالة البطارية",
            when (hc) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "جيدة"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "حرارة عالية"
                BatteryManager.BATTERY_HEALTH_DEAD -> "تالفة"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "جهد زائد"
                BatteryManager.BATTERY_HEALTH_COLD -> "باردة"
                BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "عطل"
                else -> "غير معروفة"
            }
        )
    }
}
