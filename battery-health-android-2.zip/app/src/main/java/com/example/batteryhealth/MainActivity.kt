package com.example.batteryhealth

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private val ink = Color.parseColor("#12332B")
    private val sub = Color.parseColor("#4D6B62")
    private val bg = Color.parseColor("#E8F3EE")
    private val card = Color.parseColor("#F6FBF8")
    private val line = Color.parseColor("#C5DDD3")
    private val ok = Color.parseColor("#2F9E6E")
    private val warn = Color.parseColor("#D99A1C")
    private val bad = Color.parseColor("#D6453D")

    private lateinit var big: TextView
    private lateinit var verdict: TextView
    private lateinit var source: TextView
    private lateinit var rows: LinearLayout
    private lateinit var designInput: EditText
    private var last: Intent? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            last = i
            try { render(i) } catch (t: Throwable) { showError(t) }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            buildUi()
        } catch (t: Throwable) {
            showError(t)
        }
    }

    private fun showError(t: Throwable) {
        val tv = TextView(this)
        tv.text = "حصل خطأ، صوّر هذي الشاشة وارسلها:\n\n" + android.util.Log.getStackTraceString(t)
        tv.setTextIsSelectable(true)
        tv.textSize = 12f
        tv.setPadding(dp(16), dp(40), dp(16), dp(16))
        val sv = ScrollView(this)
        sv.addView(tv)
        setContentView(sv)
    }

    private fun buildUi() {

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(40), dp(20), dp(32))

        val title = TextView(this)
        title.text = "صحة البطارية"
        title.textSize = 22f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(ink)
        col.addView(title)

        big = TextView(this)
        big.textSize = 76f
        big.setTypeface(null, Typeface.BOLD)
        big.gravity = Gravity.CENTER
        big.setTextColor(ink)
        big.layoutDirection = View.LAYOUT_DIRECTION_LTR
        col.addView(big, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })

        verdict = TextView(this)
        verdict.textSize = 18f
        verdict.setTypeface(null, Typeface.BOLD)
        verdict.gravity = Gravity.CENTER
        verdict.setTextColor(ink)
        col.addView(verdict, LinearLayout.LayoutParams(-1, -2))

        source = TextView(this)
        source.textSize = 13f
        source.gravity = Gravity.CENTER
        source.setTextColor(sub)
        col.addView(source, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        rows = LinearLayout(this)
        rows.orientation = LinearLayout.VERTICAL
        rows.background = GradientDrawable().apply {
            setColor(card)
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), line)
        }
        col.addView(rows, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(28) })

        val hint = TextView(this)
        hint.text = "إذا ما قدر التطبيق يعرف السعة الأصلية، اكتبها هنا (مثل 5000) واضغط حفظ."
        hint.textSize = 14f
        hint.setTextColor(sub)
        col.addView(hint, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })

        designInput = EditText(this)
        designInput.inputType = InputType.TYPE_CLASS_NUMBER
        designInput.hint = "السعة الأصلية بالـ mAh"
        designInput.setTextColor(ink)
        val saved = savedDesign()
        if (saved != null) designInput.setText(saved.toInt().toString())
        col.addView(designInput, LinearLayout.LayoutParams(-1, -2))

        val save = Button(this)
        save.text = "حفظ"
        save.setOnClickListener {
            val v = designInput.text.toString().toFloatOrNull() ?: 0f
            getSharedPreferences("p", MODE_PRIVATE).edit().putFloat("design", v).apply()
            last?.let { render(it) }
        }
        col.addView(save, LinearLayout.LayoutParams(-1, -2))

        scroll.addView(col)
        setContentView(scroll)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
    }

    override fun onStart() {
        super.onStart()
        try {
            val f = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val sticky = if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(receiver, f)
            }
            sticky?.let { last = it; render(it) }
        } catch (t: Throwable) {
            showError(t)
        }
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(receiver) } catch (e: Exception) { }
    }

    private fun savedDesign(): Double? {
        val v = getSharedPreferences("p", MODE_PRIVATE).getFloat("design", 0f)
        return if (v > 0f) v.toDouble() else null
    }

    private fun autoDesign(): Double? = try {
        val c = Class.forName("com.android.internal.os.PowerProfile")
        val o = c.getConstructor(Context::class.java).newInstance(this)
        (c.getMethod("getBatteryCapacity").invoke(o) as Double).takeIf { it > 0 }
    } catch (e: Throwable) {
        null
    }

    private fun addRow(label: String, value: String) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.setPadding(dp(18), dp(14), dp(18), dp(14))
        val a = TextView(this)
        a.text = label
        a.textSize = 16f
        a.setTextColor(sub)
        val b = TextView(this)
        b.text = value
        b.textSize = 16f
        b.setTypeface(null, Typeface.BOLD)
        b.setTextColor(ink)
        b.gravity = Gravity.END
        r.addView(a, LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        rows.addView(r)
    }

    private fun render(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) / 10.0
        val volt = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
        val hc = i.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)
        val cycles = i.getIntExtra("android.os.extra.CYCLE_COUNT", -1)

        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val soh = if (Build.VERSION.SDK_INT >= 34) bm.getIntProperty(10) else -1
        val counter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
        val design = savedDesign() ?: autoDesign()
        val estFull = if (pct >= 20 && counter > 0) counter / 1000.0 / (pct / 100.0) else null

        var health: Int? = null
        var src = ""
        if (soh in 1..100) {
            health = soh
            src = "القيمة من نظام الجهاز"
        } else if (estFull != null && design != null && design > 0) {
            health = Math.min(100, Math.round(estFull / design * 100).toInt())
            src = "تقدير من السعة الحالية والأصلية"
        }

        if (health != null) {
            big.text = "$health%"
            val color = if (health >= 80) ok else if (health >= 70) warn else bad
            big.setTextColor(color)
            verdict.setTextColor(color)
            verdict.text = when {
                health >= 90 -> "ممتازة"
                health >= 80 -> "جيدة"
                health >= 70 -> "متوسطة، قرّب تغييرها"
                else -> "ضعيفة، يفضّل تغيير البطارية"
            }
            source.text = src
        } else {
            big.text = "؟"
            big.setTextColor(ink)
            verdict.setTextColor(ink)
            source.text = ""
            verdict.text = when {
                design == null -> "اكتب السعة الأصلية بالأسفل"
                pct in 0..19 -> "الشحن أقل من 20%، التقدير يحتاج 20% أو أكثر"
                else -> "الجهاز ما يعطي بيانات كافية"
            }
        }

        rows.removeAllViews()
        addRow("النسبة الحالية", if (pct >= 0) "$pct%" else "غير متاح")
        addRow("الحالة", if (charging) "يشحن" else "يستخدم البطارية")
        if (estFull != null) addRow("السعة الحالية (تقدير)", "${estFull.toInt()} mAh")
        if (design != null) addRow("السعة الأصلية", "${design.toInt()} mAh")
        if (cycles >= 0) addRow("دورات الشحن", cycles.toString())
        if (temp > 0) addRow("الحرارة", "$temp °C")
        if (volt > 0) addRow("الجهد", "$volt mV")
        addRow(
            "حالة البطارية",
            when (hc) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "جيدة"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "حرارة عالية"
                BatteryManager.BATTERY_HEALTH_DEAD -> "تالفة"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "جهد زائد"
                BatteryManager.BATTERY_HEALTH_COLD -> "باردة"
                BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "عطل"
                else -> "غير معروفة"
            }
        )
    }
}
